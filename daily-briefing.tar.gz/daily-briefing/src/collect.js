#!/usr/bin/env node

/**
 * Daily Intelligence Briefing — メイン収集スクリプト
 * 
 * 使い方:
 *   node src/collect.js              # 全ソースから収集
 *   node src/collect.js --pubmed     # PubMedのみ
 *   node src/collect.js --no-summary # Claude APIを使わない（テスト用）
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const pubmed = require('./sources/pubmed');
const mhlw = require('./sources/mhlw');
const hackernews = require('./sources/hackernews');
const arxiv = require('./sources/arxiv');
const { summarizeArticles } = require('./summarize');
const { generateHTML, saveHTML } = require('./render');

// Parse CLI args
const args = process.argv.slice(2);
const onlyPubmed = args.includes('--pubmed');
const onlyMhlw = args.includes('--mhlw');
const noSummary = args.includes('--no-summary');
const isWeekly = args.includes('--weekly');

async function main() {
  console.log('═══════════════════════════════════════════════');
  console.log('  Daily Intelligence Briefing — 収集開始');
  console.log(`  ${new Date().toLocaleString('ja-JP')}`);
  console.log('═══════════════════════════════════════════════');

  // Load config
  const configPath = path.join(__dirname, '..', 'config', 'settings.json');
  const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

  const sourceCounts = {};
  let allArticles = [];
  let pubmedResults = {};
  let mhlwResults = [];
  let hnResults = [];
  let arxivResults = [];

  // ===== 1. PubMed =====
  if (!onlyMhlw) {
    pubmedResults = await pubmed.collectAll(config);
    let pubmedCount = 0;
    for (const [key, data] of Object.entries(pubmedResults)) {
      pubmedCount += data.articles.length;
      for (const article of data.articles) {
        article.source = `PubMed`;
        article.specialty = data.label;
        article.sourcePriority = data.priority;
        article.category = 'paper';
      }
    }
    sourceCounts['PubMed'] = pubmedCount;
  }

  // ===== 2. 厚労省 =====
  if (!onlyPubmed) {
    mhlwResults = await mhlw.collectAll(config);
    sourceCounts['厚労省'] = mhlwResults.length;
  }

  // ===== 3. Hacker News =====
  if (!onlyPubmed && !onlyMhlw) {
    hnResults = await hackernews.collectAll(config);
    sourceCounts['HackerNews'] = hnResults.length;
  }

  // ===== 4. arXiv (weekly only) =====
  if (isWeekly || args.includes('--arxiv')) {
    arxivResults = await arxiv.collectAll(config);
    sourceCounts['arXiv'] = arxivResults.length;
  }

  // ===== Flatten PubMed results =====
  const allPapers = [];
  for (const [key, data] of Object.entries(pubmedResults)) {
    allPapers.push(...data.articles);
  }

  // ===== Merge all non-paper items =====
  const allNews = [...mhlwResults, ...hnResults];

  // ===== 5. Claude API で要約・優先度判定 =====
  let summarizedPapers = allPapers;
  let summarizedNews = allNews;

  if (!noSummary && process.env.ANTHROPIC_API_KEY) {
    console.log('\n[Claude API] 要約・優先度判定を実行中...');
    
    if (allPapers.length > 0) {
      summarizedPapers = await summarizeArticles(allPapers, config);
    }
    if (allNews.length > 0) {
      summarizedNews = await summarizeArticles(allNews, config);
    }
  } else {
    if (!noSummary) {
      console.log('\n⚠️  ANTHROPIC_API_KEY が未設定のため、要約をスキップします');
      console.log('   設定方法: export ANTHROPIC_API_KEY="sk-ant-..."');
    }
    // Assign default priorities
    for (const p of summarizedPapers) {
      p.priority = p.priority || (p.sourcePriority === 'high' ? '要注視' : '参考');
      p.summary_ja = p.summary_ja || p.abstract?.substring(0, 200);
      p.memo = p.memo || '';
    }
    for (const n of summarizedNews) {
      n.priority = n.priority || '参考';
      n.summary_ja = n.summary_ja || n.title;
    }
  }

  // ===== 6. Categorize for output =====
  const morning = [
    ...summarizedNews.filter(i => i.category === 'regulation'),
    ...summarizedPapers.filter(i => i.priority === '要対応'),
    ...hnResults.filter(i => i.priority === '要注視' || i.priority === '要対応'),
  ];

  const papers = summarizedPapers;

  const alerts = summarizedNews.filter(i => i.category === 'regulation');

  const tech = [
    ...hnResults.map(i => ({ ...i, priority: i.priority || 'テック', section: '医療AI・テック' })),
    ...arxivResults.map(i => ({ ...i, priority: 'テック', section: 'arXiv新着' })),
  ];

  // ===== 7. Generate HTML =====
  console.log('\n[HTML] ブリーフィングを生成中...');

  const today = new Date();
  const dayOfWeek = ['日', '月', '火', '水', '木', '金', '土'][today.getDay()];
  const dateStr = `${today.getFullYear()}年${today.getMonth() + 1}月${today.getDate()}日（${dayOfWeek}）`;

  const htmlContent = generateHTML({
    morning: morning.length > 0 ? morning : summarizedNews.concat(summarizedPapers.slice(0, 5)),
    papers,
    alerts,
    tech,
    date: dateStr,
    sourceCounts,
  });

  const outputDir = path.resolve(path.join(__dirname, '..', config.output.dir));
  const filepath = saveHTML(htmlContent, outputDir);

  // ===== 8. Open in browser (optional) =====
  if (config.output.open_on_generate) {
    try {
      execSync(`open "${filepath}"`);
      console.log('🌐 ブラウザで開きました');
    } catch (e) {
      // Not on Mac or open command not available
    }
  }

  // ===== Summary =====
  console.log('\n═══════════════════════════════════════════════');
  console.log('  収集完了サマリー');
  console.log('═══════════════════════════════════════════════');
  console.log(`  PubMed論文: ${allPapers.length} 件`);
  console.log(`  厚労省トピックス: ${mhlwResults.length} 件`);
  console.log(`  Hacker News: ${hnResults.length} 件`);
  if (arxivResults.length > 0) console.log(`  arXiv: ${arxivResults.length} 件`);
  console.log(`  合計: ${allPapers.length + mhlwResults.length + hnResults.length + arxivResults.length} 件`);
  console.log(`\n  出力: ${filepath}`);
  console.log('═══════════════════════════════════════════════\n');
}

main().catch(e => {
  console.error('❌ エラー:', e.message);
  process.exit(1);
});
