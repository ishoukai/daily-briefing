/**
 * HTMLブリーフィングを生成
 */

const fs = require('fs');
const path = require('path');

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function priorityClass(priority) {
  switch (priority) {
    case '要対応': return 'p-high';
    case '要注視': return 'p-mid';
    case 'テック': return 'p-tech';
    default: return 'p-info';
  }
}

function renderCard(item) {
  const impact = item.impact
    ? `<div class="impact">${escapeHtml(item.impact)}</div>`
    : '';
  return `<div class="card">
  <div class="card-head">
    <h3>${escapeHtml(item.title)}</h3>
    <span class="priority ${priorityClass(item.priority)}">${escapeHtml(item.priority)}</span>
  </div>
  <div class="source-line">
    <span class="source">${escapeHtml(item.source || item.journal || '')} — ${escapeHtml(item.date || '')}</span>
    ${item.url ? `<a class="link-btn" href="${escapeHtml(item.url)}" target="_blank" rel="noopener">原文を読む ↗</a>` : ''}
  </div>
  <div class="body">${escapeHtml(item.summary_ja || item.abstract || '')}</div>
  ${impact}
</div>`;
}

function renderPaper(item) {
  const memo = item.memo
    ? `<div class="takeaway"><strong>理事長メモ:</strong> ${escapeHtml(item.memo)}</div>`
    : '';
  return `<div class="paper">
  <div class="journal-line">
    <span class="journal">${escapeHtml(item.journal || item.source || '')}</span>
    ${item.url ? `<a class="link-btn" href="${escapeHtml(item.url)}" target="_blank" rel="noopener">原文 ↗</a>` : ''}
  </div>
  <h3>${escapeHtml(item.title)}</h3>
  <div class="authors">${escapeHtml(item.authors || '')}</div>
  <div class="abstract">${escapeHtml(item.summary_ja || item.abstract || '')}</div>
  ${memo}
</div>`;
}

function renderSection(label) {
  return `<div class="section-label">${escapeHtml(label)}</div>`;
}

function generateHTML(data) {
  const { morning, papers, alerts, tech, date, sourceCounts } = data;

  const nHigh = morning.filter(i => i.priority === '要対応').length;
  const nMid = morning.filter(i => i.priority === '要注視').length;
  const nInfo = morning.filter(i => i.priority === '参考').length;

  // Group morning items by priority
  const morningHTML = [
    renderSection('要対応 — 経営判断に直結'),
    ...morning.filter(i => i.priority === '要対応').map(renderCard),
    renderSection('要注視 — 中期的に影響'),
    ...morning.filter(i => i.priority === '要注視').map(renderCard),
    renderSection('参考情報'),
    ...morning.filter(i => i.priority === '参考').map(renderCard),
  ].join('\n');

  // Group papers by specialty
  const specialtyMap = {};
  for (const p of papers) {
    const key = p.specialty || p.label || '一般';
    if (!specialtyMap[key]) specialtyMap[key] = [];
    specialtyMap[key].push(p);
  }
  const papersHTML = Object.entries(specialtyMap).map(([label, items]) =>
    renderSection(label) + '\n' + items.map(renderPaper).join('\n')
  ).join('\n');

  // Alerts grouped by timeline
  const alertGroups = {};
  for (const a of alerts) {
    const key = a.section || '制度変更';
    if (!alertGroups[key]) alertGroups[key] = [];
    alertGroups[key].push(a);
  }
  const alertsHTML = Object.entries(alertGroups).map(([label, items]) =>
    renderSection(label) + '\n' + items.map(renderCard).join('\n')
  ).join('\n');

  // Tech
  const techGroups = {};
  for (const t of tech) {
    const key = t.section || 'テック';
    if (!techGroups[key]) techGroups[key] = [];
    techGroups[key].push(t);
  }
  const techHTML = Object.entries(techGroups).map(([label, items]) =>
    renderSection(label) + '\n' + items.map(renderCard).join('\n')
  ).join('\n');

  // Source count pills
  const pillsHTML = Object.entries(sourceCounts || {}).map(([name, count]) =>
    `<span class="source-pill">${escapeHtml(name)} <b>${count}</b></span>`
  ).join('\n      ');

  // Read template
  const templatePath = path.join(__dirname, '..', 'templates', 'briefing.html');
  let template = fs.readFileSync(templatePath, 'utf8');

  // Replace placeholders
  template = template.replace('{{DATE}}', date || new Date().toLocaleDateString('ja-JP'));
  template = template.replace('{{SOURCE_PILLS}}', pillsHTML);
  template = template.replace('{{N_MORNING}}', String(morning.length));
  template = template.replace('{{N_PAPERS}}', String(papers.length));
  template = template.replace('{{N_ALERTS}}', String(alerts.length));
  template = template.replace('{{N_TECH}}', String(tech.length));
  template = template.replace('{{N_HIGH}}', String(nHigh));
  template = template.replace('{{N_MID}}', String(nMid));
  template = template.replace('{{N_INFO}}', String(nInfo));
  template = template.replace('{{MORNING_CONTENT}}', morningHTML);
  template = template.replace('{{PUBMED_CONTENT}}', papersHTML);
  template = template.replace('{{ALERT_CONTENT}}', alertsHTML);
  template = template.replace('{{TECH_CONTENT}}', techHTML);

  return template;
}

function saveHTML(htmlContent, outputDir) {
  const date = new Date().toISOString().split('T')[0];
  const filename = `briefing_${date}.html`;
  const filepath = path.join(outputDir, filename);
  
  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(filepath, htmlContent, 'utf8');
  
  console.log(`\n✅ ブリーフィングを生成しました: ${filepath}`);
  return filepath;
}

module.exports = { generateHTML, saveHTML };
